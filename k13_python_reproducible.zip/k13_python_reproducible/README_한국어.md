# 북부 우간다 PfK13 그림 재현 패키지

이 패키지는 원래의 QGIS 프로젝트 없이도 Python으로 논문용 그림을 재생성합니다.

## 폴더 구성

```text
k13_python_reproducible/
├── make_k13_figure.py        # 그림 그리는 코드 (수정 대상)
├── requirements.txt          # 필요한 Python 라이브러리
├── README_한국어.md
├── data/
│   ├── k13_clean.gpkg         # 우간다/남수단 경계, 조사 지점, 파이 데이터
│   └── k13_year_pies_clean.csv # 데이터 검토용 CSV
└── output/
    ├── k13_northern_uganda_publication.png
    ├── k13_northern_uganda_publication.pdf
    └── k13_northern_uganda_publication.svg
```

## Windows 실행 — 처음 한 번만

1. ZIP 파일을 `C:\\k13_map` 같은 짧고 영문인 경로에 압축 해제합니다.
2. VS Code에서 **파일 > 폴더 열기**로 `k13_python_reproducible` 폴더를 엽니다.
3. VS Code **터미널 > 새 터미널**을 열고 아래 명령을 순서대로 입력합니다.

```powershell
py -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe make_k13_figure.py
```

4. `output` 폴더에 PNG, PDF, SVG가 생성됩니다. 패키지에 이미 테스트 출력본을 넣어두었습니다.

> `py` 명령이 인식되지 않으면 설치된 Python 환경에 맞춰 `python`을 사용합니다. GeoPandas 설치에서 오류가 발생하면 conda-forge 환경을 권장합니다.

## 수정하고 다시 생성하기

코드는 `make_k13_figure.py` 한 파일만 고치면 됩니다. 저장 후 다음 명령을 실행하세요.

```powershell
.venv\Scripts\python.exe make_k13_figure.py
```

- **district 정렬 순서**: `district_order = [...]`
- **파이 크기**: `Wedge((yr,y),.285,...`의 `.285`와 `Circle((yr,y),.285,...`의 `.285`를 **같이** 조정 (`.24` 작게 / `.32` 크게)
- **변이 색상**: `colors = [...]` 배열에서 순서대로 변경
- **지도 표시 범위**: `ax.set_xlim(...)`, `ax.set_ylim(...)`
- **전체 캔버스 크기**: `figsize=(16,9.5)`
- **PNG 해상도**: `dpi=320`을 `dpi=600`으로 변경
- **Bor 표시**: `data/k13_clean.gpkg`의 `bor_context` 레이어는 공개된 Bor 도시의 대략적 위치를 표현합니다. 실제 시설 위치를 의미하지 않습니다.

주의: 왼쪽 지도에 나타난 조사 지점은 `center_lon`/`center_lat`이고, 오른쪽 연도별 파이차트는 지도좌표가 아닌 **연도별 표 형식 좌표**로 정렬되어 있습니다. `data/k13_clean.gpkg`의 `x_plot`/`y_plot`은 별도의 QGIS 지도용 위치 필드이며, 이 그림의 오른쪽 패널 배치에는 사용되지 않습니다.

## 원자료와 해석 주의

Supplementary Table S3는 변이별 `Mut/N`을 제시하며, 변이마다 분모가 다릅니다. 여기서 파이의 회색 부분은 원래 데이터 처리 과정에서 `max(변이별 분모) - sum(주요 변이 count)`로 계산된 **시각화용 근사치**입니다. **확정적인 wild-type 비율이나 개인별 상호배타적 genotype 비율로 해석하면 안 됩니다.** 원자료의 변이별 출현률을 엄밀하게 비교하려면 각 변이별 prevalence(%)를 선 그래프/막대그래프로 표현하는 것이 더 적절합니다.

논문에 쓰기 전에 연구 범위, 공식 행정경계의 버전, 원자료와 분모 및 그림의 legend/caption을 검증하세요.
