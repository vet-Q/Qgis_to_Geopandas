#!/usr/bin/env python3
"""Reproduce the northern Uganda PfK13 publication map.

Run from anywhere: python make_k13_figure.py
Inputs are in data/, outputs are in output/.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Wedge, Circle, Patch
from matplotlib import patheffects
from matplotlib.gridspec import GridSpec

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
output_dir = ROOT / "output"
output_dir.mkdir(exist_ok=True)
gpkg = DATA / "k13_clean.gpkg"
if not gpkg.exists():
    raise FileNotFoundError(f"Missing input GeoPackage: {gpkg}")

pies = gpd.read_file(gpkg, layer="year_pies")
site = gpd.read_file(gpkg, layer="surveillance_districts")
uga = gpd.read_file(gpkg, layer="uganda_admin2")
ssd = gpd.read_file(gpkg, layer="south_sudan_country")
bor = gpd.read_file(gpkg, layer="bor_context")
a = pies.copy()
cols = ["n_P441L", "n_C469Y", "n_A675V", "n_C469F", "n_R561H", "n_no_key_mutation_approx"]
for col in cols:
    a[col] = pd.to_numeric(a[col], errors="coerce")
a["year"] = pd.to_numeric(a["year"], errors="coerce")
a = a[a["year"].notna()].copy()
a["year"] = a["year"].astype(int)
pies = a
positions = pies[["district", "center_lon", "center_lat"]].drop_duplicates("district")
# Adjust colors and pie radius below to customize the figure.
# publication style image: geographic map left, rows of pies right (exact 7-column align)
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'svg.fonttype':'none','font.size':10})
fig=plt.figure(figsize=(16,9.5),facecolor='white');gs=GridSpec(1,2,width_ratios=[1.16,1.16],left=.045,right=.97,top=.875,bottom=.18,wspace=.075)
ax=fig.add_subplot(gs[0,0]); ax2=fig.add_subplot(gs[0,1]);ax.set_aspect('equal')
# geographic plot
ssd_clip=ssd.cx[29.0:36.8,0.8:7.2];uga_clip=uga.cx[29.0:36.8,0.8:7.2]
ssd_clip.plot(ax=ax,color='#EDF0F3',edgecolor='#B7C0C9',linewidth=.38,zorder=1)
uga_clip.plot(ax=ax,color='#FAFBFC',edgecolor='#D4DCE3',linewidth=.4,zorder=2)
site.plot(ax=ax,color='#F7D9A2',edgecolor='#AF874F',linewidth=.85,zorder=3)
# country boundary outlines
for poly_df in [ssd_clip,uga_clip]:
 poly_df.dissolve().boundary.plot(ax=ax,color='#586674',linewidth=1.25,zorder=4)
# District center positions are derived from stored location fields
for _,r in positions.iterrows():
 ax.scatter(r.center_lon,r.center_lat,s=33,color='#B44C36',edgecolors='white',linewidth=1.3,zorder=6)
 # label district, small
 ax.annotate(r.district,(r.center_lon,r.center_lat),xytext=(5,6),textcoords='offset points',fontsize=8.3,fontweight='semibold',color='#233B4A',zorder=7,path_effects=[patheffects.withStroke(linewidth=2.3,foreground='white')])
ax.scatter(float(bor.geometry.x.iloc[0]),float(bor.geometry.y.iloc[0]),s=105,marker='*',color='#274E77',edgecolors='white',linewidth=.7,zorder=8)
ax.annotate('Bor / Jonglei\nHanbit study context',xy=(float(bor.geometry.x.iloc[0]),float(bor.geometry.y.iloc[0])),xytext=(32.1,6.25),fontsize=9,color='#274E77',weight='semibold',arrowprops={'arrowstyle':'-','color':'#687A8B','lw':.9})
ax.text(32.8,5.55,'SOUTH SUDAN',fontsize=15,weight='bold',color='#7C8995',alpha=.8)
ax.text(31.15,1.23,'UGANDA',fontsize=15,weight='bold',color='#7C8995',alpha=.8)
ax.set_xlim(29.4,36.0);ax.set_ylim(.9,7.05);ax.set_xticks([]);ax.set_yticks([]);[sp.set_visible(False) for sp in ax.spines.values()]
ax.set_title('A  Geographic context of surveillance sites',loc='left',weight='bold',fontsize=13,pad=12,color='#18374D')
# chart panel
colors=['#D4AE35','#3C9277','#DB5E52','#668AB9','#8570AD','#DEE4E8']
labels=['P441L','C469Y','A675V','C469F','R561H','No key marker*']
district_order=['Lamwo','Agago','Kaabong','Katakwi','Koboko','Arua','Kole','Amolatar']
ax2.set_xlim(2014.65,2023.35);ax2.set_ylim(-.85,7.8);ax2.set_aspect('equal',adjustable='box')
for i,d in enumerate(district_order):
 y=7-i
 ax2.axhline(y,color='#EDF1F4',linewidth=18,zorder=0)
 ax2.text(2014.82,y,d,ha='left',va='center',fontsize=10.2,fontweight='semibold',color='#233B4A')
 for yr in range(2016,2023):
  sub=pies[(pies.district==d)&(pies.year==yr)]
  if len(sub)==0:continue
  r=sub.iloc[0];v=np.array([max(0,float(r[c])) if pd.notna(r[c]) else 0 for c in cols])
  if v.sum()<=0:continue
  start=90
  for val,color in zip(v,colors):
   if val<=0:continue
   angle=float(val/v.sum()*360)
   ax2.add_patch(Wedge((yr,y),.285,start,start+angle,facecolor=color,edgecolor='white',linewidth=.45,zorder=3))
   start+=angle
  ax2.add_patch(Circle((yr,y),.285,fill=False,edgecolor='#637889',linewidth=.55,zorder=4))
  ax2.text(yr,y-.41,str(yr)[2:],ha='center',va='center',fontsize=6.7,color='#60707D')
for yr in range(2016,2023):ax2.text(yr,7.57,str(yr),ha='center',va='center',fontsize=9.1,fontweight='bold',color='#18374D')
ax2.set_xticks([]);ax2.set_yticks([]);[sp.set_visible(False) for sp in ax2.spines.values()]
ax2.set_title('B  Yearly PfK13 marker profiles by district',loc='left',weight='bold',fontsize=13,pad=12,color='#18374D')
fig.text(.045,.955,'PfK13 marker surveillance in northern Uganda',fontsize=20,weight='bold',color='#15364A')
fig.text(.046,.918,'Spatial context and temporal distribution, 2016–2022  |  Adapted from Conrad et al., NEJM supplementary Table S3',fontsize=10.2,color='#687D8B')
handles=[Patch(facecolor=c,edgecolor='white',label=l) for c,l in zip(colors,labels)]
fig.legend(handles=handles,ncol=6,loc='lower center',bbox_to_anchor=(.53,.12),frameon=False,fontsize=9.5,columnspacing=1.7,handlelength=1.3)
fig.text(.05,.072,'*Approximate category = maximum locus-specific denominator minus summed marker counts. Not a verified wild-type genotype category.',fontsize=9.3,color='#5D6770')
fig.text(.05,.042,'Pie segments are descriptive approximations from locus-specific denominators; they are not patient-level mutually exclusive haplotypes. Missing surveillance years are blank.',fontsize=8.7,color='#5D6770')
for ext in ['png','pdf','svg']:
 kw={'dpi':320} if ext=='png' else {}
 fig.savefig(str(output_dir / f'k13_northern_uganda_publication.{ext}'),facecolor='white',**kw)
plt.close(fig)
print('Saved figures in:', output_dir)
